/* Based on OF/Maximilian starting example framework

Advanced-AV Processing Coursework

Example 4: Interactive Video Playback Manipulation with ofVideoPlayer. My perception of a jumbled debate circa the 2016 election.
 **The majority of the functionality is through keyboard/mouse controls, so check the respective sections to see it all!
 
Julia Wilkins
*/

#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    
    /* This is stuff you always need.*/
    sampleRate 	= 44100; /* Sampling Rate */
    bufferSize	= 512; /* Buffer Size. you have to fill this buffer with sound using the for loop in the audioOut method */
    
    //load up videos of hillary and trump speeches
    trump.load("trump.mp4");
    hillary.load("hillary.mp4");
    
    // By setting the ofPixel format to RGBA instead of RGB, we get a strange image echoing effect
    trumpDouble.allocate(600, 400, OF_PIXELS_RGBA);
    trumpTexture.allocate(trumpDouble);
    
    ofSetVerticalSync(true);
    
    ofSoundStreamSetup(2,2,this, sampleRate, bufferSize, 4);
}

//--------------------------------------------------------------
void ofApp::update(){
    
    trump.update();
    hillary.update();
    
    // Trump loves himself so let's see more of him
    if(trump.isFrameNew()){
        ofPixels & pixelsTrump = trump.getPixels();
        
        for(int i = 0; i < pixelsTrump.size(); i++){
            trumpDouble[i] = pixelsTrump[i];
        }
        trumpTexture.loadData(trumpDouble);
    }
    
}



//--------------------------------------------------------------
void ofApp::draw(){
    ofBackground(0);
    trump.draw(0, 165, 0.5*ofGetWidth(), ofGetHeight() - 165) ;
    hillary.draw(0.5*ofGetWidth(), 165, 0.5*ofGetWidth(), ofGetHeight() - 165);
    
    ofDrawBitmapString("Key Codes:", 10, 20);
    ofDrawBitmapString("Hover mouse left to right over each clicp to control separate playback speeds!", 10, 35);
    ofDrawBitmapString("Clicking on either clip will jump to a random frame", 10, 50);
    ofDrawBitmapString("Click+drag mouse for reverse playback", 10, 65);
    ofDrawBitmapString("1: restart Trump", 10, 80);
    ofDrawBitmapString("2: restart Hillary:", 10, 95);
    ofDrawBitmapString("r: pauses Trump", 10, 110);
    ofDrawBitmapString("u: pauses Hillary", 10, 125);
    ofDrawBitmapString("y: pauses both", 10, 140);
    ofDrawBitmapString("Move mouse to unpause", 10, 155);
    
    // Add our two textures
    trumpTexture.draw(0, 165, 600, 465);
    
}

//--------------------------------------------------------------
void ofApp::audioOut(float * output, int bufferSize, int nChannels) {
    
    
    for (int i = 0; i < bufferSize; i++) {
        
        /* Stick your maximilian 'play()' code in here ! Declare your objects in ofApp.h
         
         For information on how maximilian works, take a look at the example code at
         
         http://www.maximilian.strangeloop.co.uk
         
         under 'Tutorials'.
         
         */
        
        output[i*nChannels    ] = 0; /* You may end up with lots of outputs. add them here */
        output[i*nChannels + 1] = 0;
        
    }
    
}

//--------------------------------------------------------------
void ofApp::audioIn(float * input, int bufferSize, int nChannels){
    
    // samples are "interleaved"
    for(int i = 0; i < bufferSize; i++){
        /* you can also grab the data out of the arrays*/
        
    }
    
}


//--------------------------------------------------------------
void ofApp::keyPressed(int key){
    
    
    //1 to restart trump clip
    if(key==49){
        trump.setFrame(1);
    }
    
    //2 to restart hillary clip
    if(key==50){
        hillary.setFrame(1);
    }
    
    //r pauses trump only
    if(key==114){
        trump.setPaused(true);
    }
    
    //u pauses hillary only
    if(key==85){
        hillary.setPaused(true);
    }
    
    //y pauses both
    if(key==121){
        trump.setPaused(true);
        hillary.setPaused(true);
    }
    //simply move the mouse again to get both going
    
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){
    
}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y){
    
    //Playback speed increases as you drag the mouse farther across each clip (increasing along x-axis)
    if(x > 200 && x<0.5*ofGetWidth()){
        trump.setSpeed(x/200);
    }
    
    else{
        trump.setSpeed(1);
    }
    
    if(x >0.5*ofGetWidth() && x<ofGetWidth()){
        hillary.setSpeed(x/400);
    }
    else{
        hillary.setSpeed(1);
    }
    
    
    
}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){
    
    //If you hold and drag the mouse they will start talking backwards (this is bad and laggy)
    if(x>0 && 0.5*x<ofGetWidth()){
        trump.setSpeed(-1);
    }
    if(x>0.5*ofGetWidth() && x<ofGetWidth()) {
        hillary.setSpeed(-1);
    }
}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
    
    //Click on either of them to jump to a random frame within that video
    if(x>0 && x<0.5*ofGetWidth()){
        trump.setPosition(ofRandom(1));
    }
    
    if(x>0.5*ofGetWidth() && x<ofGetWidth()) {
        hillary.setPosition(ofRandom(1));
    }
}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){
    
}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){
    
}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){
    
}
