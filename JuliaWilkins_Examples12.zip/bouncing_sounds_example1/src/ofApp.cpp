#include "ofApp.h"
/* 
 Julia Wilkins
 Advanced AV-Processing
 Example 1: Bouncing Ball Synthesizer
 
 I was intrigued by a basic example of a bouncing ball that we created in PMC, so I decided to extend that into openFrameworks by creating a ball that bounces off of each wall and creates a unique sound when it hits each wall. I added the GUI to create more interactivity so that the user can personalize the frequencies of each wall, and also implemented a basic delay line to add some texture to the sound. I have explained each component in much more detail in the associate comment sections below. Enjoy!
*/

//--------------------------------------------------------------
void ofApp::setup(){
    
    /* This is stuff you always need.*/
    
    ofSetFrameRate(60);
    
    sampleRate 	= 44100; /* Sampling Rate */
    bufferSize	= 512; /* Buffer Size. you have to fill this buffer with sound using the for loop in the audioOut method */
    
    ofxMaxiSettings::setup(sampleRate, 2, bufferSize);
    
    ofSetVerticalSync(true);
    ofEnableAlphaBlending();
    ofEnableSmoothing();
    
    // Use ball struct to set the default properties of our bouncing ball
    ball1.x = ofRandom(0, ofGetWidth());
    ball1.y = ofRandom(0, ofGetHeight());
    ball1.vx = ofRandom(0, 20);
    ball1.vy = ofRandom(0, 20);
    ball1.size = ofRandom(10, 50);
    ball1.color = ofColor(ofRandom(0, 255), ofRandom(0, 255), ofRandom(0, 255));
    
    topBool = false;
    bottomBool = false;
    rightBool = false;
    leftBool = false;
    
    // Setup the controller GUI
    gui.setDefaultWidth(150);
    gui.setDefaultHeight(30);
    gui.setup();
    gui.add(topFreq.setup("Top Freq", 400, 20, 5000));
    gui.add(bottomFreq.setup("Bottom Freq", 200, 20, 5000));
    gui.add(leftFreq.setup("Left Freq", 600, 20, 5000));
    gui.add(rightFreq.setup("Right Freq", 333, 20, 5000));
    gui.add(sizerooni.setup("Ball Size", 30, 1, 300));
    
    ofSoundStreamSetup(2,2,this, sampleRate, bufferSize, 4); /* this has to happen at the end of setup - it switches on the DAC */
    
}

//--------------------------------------------------------------
void ofApp::update(){
    
    // Ball size is controlled by the GUI
    ball1.size = sizerooni;
    
    // These if statements control what happens when the ball collides with each wall. I used simple physics to determine that the ball should have the opposite velocity that it had upon collision + its current position, to keep a natural, 'bouncing off the wall' motion. See the audioout section for my explanation of the audio associated with each collision!
    
    // Hits left wall
    if(ball1.x < 0){
        ball1.x = 0;
        ball1.vx = -1 * ball1.vx; // bounce ball in opposite direction
        if(leftBool == false){ // use booleans to trigger the sounds
            leftBool = true;
        }
        else{
            leftBool = false; // if the ball hits this wall again, 'turn it off'
        }
        ball1.color = ofColor(ofRandom(0, 255), ofRandom(0, 255), ofRandom(0, 255)); //randomize color with each collision
    }
    
    // Hits right wall
    else if(ball1.x > ofGetWidth()) {
        ball1.x = ofGetWidth();
        ball1.vx = -1 * ball1.vx;
        if(rightBool == false){
            rightBool = true;
        }
        else{
            rightBool = false;
        }
        ball1.color = ofColor(ofRandom(0, 255), ofRandom(0, 255), ofRandom(0, 255));
    }
    
    // Hits top wall
    if(ball1.y < 0){
        ball1.y = 0;
        ball1.vy = -1 * ball1.vy;
        if(topBool == false){
            topBool = true;
        }
        else{
            topBool = false;
        }
        ball1.color = ofColor(ofRandom(0, 255), ofRandom(0, 255), ofRandom(0, 255));
    }
    
    // Hits bottom wall
    else if(ball1.y > ofGetHeight()){
        ball1.y = ofGetHeight();
        ball1.vy = -1 * ball1.vy;
        if(bottomBool == false){
            bottomBool = true;
        }
        else{
            bottomBool = false;
        }
        ball1.color = ofColor(ofRandom(0, 255), ofRandom(0, 255), ofRandom(0, 255));
    }
    
    // Update to reflect ball's position in the next frame. aka move the ball!
    ball1.x = ball1.x + (ball1.vx * 0.9);
    ball1.y = ball1.y + (ball1.vy * 0.9);
}

//--------------------------------------------------------------
void ofApp::draw(){
    
    ofBackground(0);
    gui.draw();
    ofSetColor(ball1.color);
    ofDrawCircle(ball1.x, ball1.y, ball1.size);
    
}

//--------------------------------------------------------------
void ofApp::audioOut(float * output, int bufferSize, int nChannels) {
    
    // Wall frequency arrays
    float top[1] = {topFreq};
    float bottom[1] = {bottomFreq};
    float right[1] = {rightFreq};
    float left[1] = {leftFreq};

    for (int i = 0; i < bufferSize; i++){

        // As the ball bounces off the different walls, a sinewave is played with some added delay. The frequencies of the walls can be controlled in the GUI. This creates a pretty cool stochastic music generation process. The amplitude of the tones is controlled by the incoming x/y velocity of the ball. I also add some delay to the outputs to give it some texture. I hard coded the delay time and amplitude, and normalized a bit to make sure the amplitude is still in a good range.
        
        // LEFT WALL
        if(leftBool == true){
            myOut1 = switchOsc.sinewave(left[0]) * ofMap(ball1.vx, -20, 20, 0, 0.5); // map velocity to appropriate amplitude range
            myOut1 = (myOut1+(delay.dl(myOut1, 4000, 0.8)*0.5))/4; // add delay
        }

        // RIGHT WALL
        if(rightBool == true){
            myOut2 = switchOsc.sinewave(right[0]) * ofMap(ball1.vx, -20, 20, 0, 0.5);
            myOut2 = (myOut2+(delay.dl(myOut2, 10000, 0.8)*0.5))/4;
        }
        
        // TOP WALL
        if(topBool == true){
            myOut3 = switchOsc.sinewave(top[0]) * ofMap(ball1.vy, -20, 20, 0, 0.5);
            myOut3 = (myOut3+(delay.dl(myOut3, 8000, 1)*0.5))/4;
        }
        
        // BOTTOM WALL
        if(bottomBool == true){
            myOut4 = switchOsc.sinewave(bottom[0]) * ofMap(ball1.vy, -20, 20, 0, 0.5);
            myOut4 = (myOut4+(delay.dl(myOut4, 5000, 0.9)*0.5))/2;
            
        }
        
        // Generate final output.
        finalOut =  myOut1 + myOut2 + myOut3 + myOut4;
        
        
        output[i*nChannels    ] = finalOut; /* You may end up with lots of outputs. add them here */
        output[i*nChannels + 1] = finalOut;

        
    }
    
    
}

//--------------------------------------------------------------
void ofApp::audioIn(float * input, int bufferSize, int nChannels){
    
    for(int i = 0; i < bufferSize; i++){
        /* you can also grab the data out of the arrays*/
        
    }
    
}


//--------------------------------------------------------------
void ofApp::keyPressed(int key){
    

    
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){
    
}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y){
  
}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
    

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){
    
    
}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){
    
}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){
    
}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){
    
}
