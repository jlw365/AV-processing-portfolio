/* Based on original empty example template.

Julia Wilkins
Advanced AV-Processing
Example 2: A Reactive Drum Machine
 
I chose to implement a simple drum machine that uses the current individual amplitudes
of the hihat, snare, kick, and crash to control the visual parameters (the colored spheres).
The playback speed of the built in beats is controlled via the Y position of the mouse.
 
 */

#include "ofApp.h"


//--------------------------------------------------------------
void ofApp::setup(){
    
    /* This is stuff you always need.*/
    
    ofSetFrameRate(60);
    //ofBackground(0,0,0);
    
    sampleRate 	= 44100; /* Sampling Rate */
    bufferSize	= 512; /* Buffer Size. you have to fill this buffer with sound using the for loop in the audioOut method */
    
    ofxMaxiSettings::setup(sampleRate, 2, bufferSize);
    
    ofSetVerticalSync(true);
    ofEnableAlphaBlending();
    ofEnableSmoothing();
    
    // Load samples
    crash.load(ofToDataPath("crash_samp.wav"));
    kick.load(ofToDataPath("kick_samp.wav"));
    snare.load(ofToDataPath("snare_samp.wav"));
    hihat.load(ofToDataPath("hihat_samp.wav"));
    
    ofSoundStreamSetup(2,2,this, sampleRate, bufferSize, 4); /* this has to happen at the end of setup - it switches on the DAC */
    
}

//--------------------------------------------------------------
void ofApp::update(){
    

}

//--------------------------------------------------------------
void ofApp::draw(){
    
    ofBackground(0);
    
    ofSetColor(255, 255, 255);
    ofDrawBitmapString("Keys:", 20, 20);
    ofDrawBitmapString("1: start preset beat 1, 2 to stop", 20, 35);
    ofDrawBitmapString("3: start preset beat 2, 4 to stop", 20, 50);
    ofDrawBitmapString("u: hihat", 20, 65);
    ofDrawBitmapString("t: snare", 20, 80);
    ofDrawBitmapString("r: kick", 20, 95);
    ofDrawBitmapString("7: crash", 20, 110);
    
    // Draw 4 spheres for each part of the kit and control the radius parameters with their respective amplitudes.
    
    // hihat
    ofSetColor(255, 0, 255);
    ofDrawSphere(ofGetWidth()/3, ofGetHeight()/3, 100, 300*hihatOut + 70);
    
    // snare
    ofSetColor(255, 0, 0);
    ofDrawSphere(2*ofGetWidth()/3, ofGetHeight()/3, 100, 200*snareOut + 70);

    // kick
    ofSetColor(0, 255, 255);
    ofDrawSphere(ofGetWidth()/3, 2*ofGetHeight()/3, 100, 100*kickOut + 70);
    
    // crash
    ofSetColor(0, 255, 0);
    ofDrawSphere(2*ofGetWidth()/3, 2*ofGetHeight()/3, 100, 200*crashOut + 70);
    
    
}

//--------------------------------------------------------------
void ofApp::audioOut(float * output, int bufferSize, int nChannels) {
    
    // Built-in pattern 1
    int kickHit[16] = {1,0,0,0,0,0,1,0,1,0,1,0,0,0,0,0};
    int snareHit[16] = {0,0,0,0,1,0,0,1,0,1,0,0,1,0,1,1};
    int hihatHit[16] = {1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0};
    int crashHit[16] = {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    
    // Built-in pattern 2
    int kickHit2[16] =  {1,0,0,0,0,0,1,0,0,0,1,0,0,0,1,0};
    int snareHit2[16] = {0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0};
    int hihatHit2[16] = {1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0};
    int crashHit2[16] = {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    
    
    for (int i = 0; i < bufferSize; i++){
        

        // If we select pattern 1, play through the array 1 patterns:

        if(beatBool1 == true){
            currentCount = (int)timer.phasor(playbackSpeed); //metro
        
            if(prevCount != currentCount) { //if its going to next timer int
            
                kickTrig = kickHit[playHead % 16];
                snareTrig = snareHit[playHead % 16];
                hihatTrig = hihatHit[playHead % 16];
                crashTrig = crashHit[playHead % 16];
            
                playHead++;
                prevCount = 0; //reset
            
            }
        }
        
        // If we select pattern 2, play through the array 2 patterns:
        
        if(beatBool2 == true){
            currentCount = (int)timer.phasor(playbackSpeed); //metro
            
            if(prevCount != currentCount) { //if its going to next timer int
                
                kickTrig = kickHit2[playHead % 16];
                snareTrig = snareHit2[playHead % 16];
                hihatTrig = hihatHit2[playHead % 16];
                crashTrig = crashHit2[playHead % 16];
                
                playHead++;
                prevCount = 0; //reset
                
            }
        }
        
        
        //Simple way to trigger each sample individually
        
        if(kickTrig == 1){
            kick.trigger();
        }
        
        if(snareTrig == 1){
            snare.trigger();
        }
        
        if(hihatTrig == 1){
            hihat.trigger();
        }
        
        if(crashTrig == 1){
            crash.trigger();
        }
        
        snareOut = snare.playOnce()*0.3;
        kickOut = kick.playOnce()*0.5;
        hihatOut = hihat.playOnce()*3;
        crashOut = crash.playOnce()*0.5;
        
        // generate output
        sampOut = kickOut+ snareFilter.lopass(snareOut, 0.7) + hihatOut + crashOut;
        
        output[i*nChannels    ] = sampOut; /* You may end up with lots of outputs. add them here */
        output[i*nChannels + 1] = sampOut;
        
        // resets
        kickTrig = 0;
        snareTrig = 0;
        hihatTrig = 0;
        crashTrig = 0;
        
    }
    
    
}

//--------------------------------------------------------------
void ofApp::audioIn(float * input, int bufferSize, int nChannels){
    
    for(int i = 0; i < bufferSize; i++){
        /* you can also grab the data out of the arrays*/
        
    }
    
}


//--------------------------------------------------------------
void ofApp::keyPressed(int key){
    
    // Key features so you can 'play' the kit with the keyboard
    // 7 = crash, t = snare, u = hihat, r = kick
    
    if(key==55){ //7
        crashTrig =1;
    }
    if(key==116){ //t
        snareTrig =1;
    }
    if(key==117){ //u
        hihatTrig=1;
    }
    if(key==114){ //r
        kickTrig=1;
    }
    
    //turn on preset beat 1 by pressing 1
    if(key==49){
        beatBool1=true;
    }
    // stop it with 2
    if(key==50){ // (2)
        beatBool1=false;
    }
    
    //turn on preset beat 2 by pressing 3
    if(key==51){ // (3)
        beatBool2=true;
    }
    // stop it with 4
    if(key==52){ // (4)
        beatBool2=false;
    }
    
    
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){
    
}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y){
    // Playback speed changes based on y position of the mouse
    playbackSpeed = (y + 400) / 90;
    
}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
    
    
}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){
    
    
}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){
    
}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){
    
}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){
    
}
