#include "ofApp.h"

//--------------------------------------------------------------
/*
 Advanced AV-Processing Coursework Project
 Julia Wilkins
 
 An Interactive Visualization Tool for Frequency and Amplitude Modulation
 
 This project demonstrates the simple yet facinating concepts of FM and AM modulation. The user is able to manipulate all parameters of the sounds and explore how FM/AM modulation really works. In the FM demo, the frequency controls the size of the spheres. The main sphere illustrates the modulated signal, while the rings illustrate the carrier and modulating wave. Enjoy!
 
 *see in-depth description on website*
*/
//--------------------------------------------------------------
void ofApp::setup(){
    
    /* This is stuff you always need.*/
    
    ofSetFrameRate(60);

    // Set up our slider panel for the FM modulation
    gui.setDefaultWidth(220);
    gui.setDefaultHeight(30);
    gui.setup();
    gui.add(freqSlider.setup("Carrier Frequency", 440, 10, 4000));
    gui.add(modIndexSlider.setup("Modulation Index", 100, 10, 2000));
    gui.add(modFreqSlider.setup("Modulation Frequency", 0.5, 0, 5));
    
    
    // Slider panel for AM modulation
    gui2.setDefaultWidth(220);
    gui2.setDefaultHeight(30);
    gui2.setup();
    gui2.add(origSlider.setup("Carrier Frequency", 440, 10, 5000));
    gui2.add(modSlider.setup("Modulation Frequency", 1, 0, 8));
    gui2.add(ampSlider.setup("Louder?", 1, 0, 5));

    sampleRate 	= 44100; /* Sampling Rate */
    bufferSize	= 512; /* Buffer Size. you have to fill this buffer with sound using the for loop in the audioOut method */
    
    randColor = false;
    square = false;
    
    ofxMaxiSettings::setup(sampleRate, 2, bufferSize);
    
    ofSetVerticalSync(true);
    ofEnableAlphaBlending();
    ofEnableSmoothing();
    FM = false;
    AM = false;
    
    ofSoundStreamSetup(2,2,this, sampleRate, bufferSize, 4); /* this has to happen at the end of setup - it switches on the DAC */
    
}

//--------------------------------------------------------------
void ofApp::exit(){
    
    }

//--------------------------------------------------------------
void ofApp::update(){
    
    
}

//--------------------------------------------------------------
void ofApp::draw(){
    
    ofBackground(0);
    gui.draw();
    gui2.draw();
    
    // Draw all the text stuff
    ofSetColor(244, 0, 255);
    ofDrawBitmapString("FREQUENCY MODULATION", ofGetWidth()-900, 50);
    ofSetColor(0, 200, 200);
    ofDrawBitmapString("Current Frequency: " + ofToString(freqVals), ofGetWidth()-900, 70);\
    
    ofSetColor(244, 0, 255);
    ofDrawBitmapString("AMPLITUDE MODULATION", ofGetWidth() - 300, 50);
    ofSetColor(0, 200, 200);
    ofDrawBitmapString("Current RMS: " + ofToString(RMS), ofGetWidth() - 300, 70);
    
    ofSetColor(244, 0, 255);
    ofDrawBitmapString("Press 'f' for FM demo, 'a' for AM demo.", 15, ofGetHeight()-80);
    ofDrawBitmapString("Press 1 for random colors. Press 2 to revert to original.", 15, ofGetHeight()-65);
    ofDrawBitmapString("Press and hold 3 for square wave!", 15, ofGetHeight()-50);
    ofDrawBitmapString("Press and hold 4 for sawtooth wave!", 15, ofGetHeight()-35);
    ofDrawBitmapString("Press and hold 5 for triangle wave!", 15, ofGetHeight()-20);
 
    
    // FM Shapes //
    
    // Randomizes color every frame to create cool afterimages and fun!
    if(randColor == true){
        ofSetColor(ofRandom(0, 255), ofRandom(0, 255), ofRandom(0, 255));
    }
    else{
        // Color also changes based on frequency
        ofSetColor(0, freqVals/12, freqVals/12);
    }
    
    // Sphere changes size based on the current frequency
    ofFill();
    ofDrawSphere(400, ofGetHeight()/2, freqVals/12);
    
    // Carrier wave frequency circle
    ofNoFill();
    ofSetLineWidth(4);
    ofSetColor(0, 0, 240);
    ofDrawCircle(150, ofGetHeight()/2, freqSlider/12);
    
    // Modulating wave frequency circle
    ofSetColor(230, 230, 100);
    ofDrawCircle(150, ofGetHeight()/2, helperVals/12);

    
    // AM Shapes //
    
    // AM mod main sphere
    // Randomizes color every frame to create cool afterimages and fun!
    
    ofFill();
    if(randColor == true){
        ofSetColor(ofRandom(0, 255), ofRandom(0, 255), ofRandom(0, 255));
    }
    else{
        // Color also changes based on frequency
        ofSetColor(0,RMS*150, RMS*150);
    }
    //ofSetColor(0,RMS*150, RMS*150); // Color changes based on RMS as well
    ofDrawSphere(1000, ofGetHeight()/2, RMS * 130);
    
    // Carrier wave frequency sphere -> these also react to their individual amplitudes
    // These two circles show the carrier and modulating wave amplitudes
    ofNoFill();
    ofSetLineWidth(4);
    ofSetColor(0, 0, 240);
    ofDrawCircle(750, ofGetHeight()/2, RMS2 * 130);
    
    // Modulating wave frequency sphere
    ofSetColor(230, 230, 100);
    ofDrawCircle(750, ofGetHeight()/2, RMS3 * 130);
    
}

//--------------------------------------------------------------
void ofApp::audioOut(float * output, int bufferSize, int nChannels) {
    
    sum = 0;
    sum2 = 0;
    sum3 = 0;
    
    for (int i = 0; i < bufferSize; i++){
        
        // FM Modulation!
        
        // Really intersting to check out the different waveforms and visualize them:
        // Square wave version
        
        if(FM == true){
        if(square == true){
            helperVals = fmHelper.square(modFreqSlider)*modIndexSlider;
            freqVals = freqSlider+helperVals;
            mod = (fmOsc.square(freqVals));
        }
        
        // Sawtooth wave version
        else if(saw == true){
            helperVals = fmHelper.sawn(modFreqSlider)*modIndexSlider;
            freqVals = freqSlider+helperVals;
            mod = (fmOsc.sawn(freqVals));
            
        }
        
        // Triangle wave version
        else if(tri == true){
            helperVals = fmHelper.triangle(modFreqSlider)*modIndexSlider;
            freqVals = freqSlider+helperVals;
            mod = (fmOsc.sawn(freqVals));
            
        }
        
        // Default is sinewave
        else{
            helperVals = fmHelper.sinewave(modFreqSlider)*modIndexSlider;
            freqVals = freqSlider+helperVals;
            mod = (fmOsc.sinewave(freqVals));
            
        }
        }
        
        // AM MODULATION - Same scenario with simple multiplicative AM modulation
        // Here, the RMS is controlling the size and color of the sphere!
        
        else if(AM == true){
            // Square wave version
            if(square == true){
                origVals = amHelper.square(origSlider);
                modVals = amModder.square(modSlider);
                mod = origVals * modVals;
                mod = mod * ampSlider;
            }
            
            // Sawtooth wave version
            else if(saw == true){
                origVals = amHelper.sawn(origSlider);
                modVals = amModder.sawn(modSlider);
                mod = origVals * modVals;
                mod = mod * ampSlider;
            }
            
            // Triangle wave version
            else if(tri == true){
                origVals = amHelper.triangle(origSlider);
                modVals = amModder.triangle(modSlider);
                mod = origVals * modVals;
                mod = mod * ampSlider;
            }
            
            // Default is sinewave
            else{
                origVals = amHelper.sinewave(origSlider);
                modVals = amModder.sinewave(modSlider);
                mod = origVals * modVals;
                mod = mod * ampSlider;
            }
        }
        
        output[i*nChannels    ] = mod; /* You may end up with lots of outputs. add them here */
        output[i*nChannels + 1] = mod;
        
        sum = sum + fabs(mod);
        sum2 = sum2 + fabs(origVals);
        sum3 = sum3 + fabs(modVals);
    }
    
    // Calculate root mean squared (RMS) amplitude by averaging the sum of the output amplitude over the buffer size and then taking the square root
    RMS = sqrt(sum / bufferSize);
    RMS2 = sqrt(sum2 / bufferSize);
    RMS3 = sqrt(sum3 / bufferSize);
    
}

//--------------------------------------------------------------
void ofApp::audioIn(float * input, int bufferSize, int nChannels){
    
    for(int i = 0; i < bufferSize; i++){
        /* you can also grab the data out of the arrays*/
        
    }
    
}


//--------------------------------------------------------------
void ofApp::keyPressed(int key){
    
    // If you press 1 it will flash through random colors, generating some sweet afterimages!
    if(key==49){
         randColor = true;
    }
    // Press 2 to go back to solid
    if(key == 50){
        randColor = false;
    }
    
    // Press and hold 3 to hear and visualize a square wave version of this
    if(key==51){
        square = true;
    }
    
    // Press and hold 4 to hear and visualize a sawtooth wave version of this
    if(key == 52){
        saw = true;
    }
    
    // Press and hold 5 to hear and visualize a triangle wave version of this
    if(key == 53){
        tri = true;
    }
    
    // Flip between the AM/FM Demo
    if(key == 102){ // F for FM
        FM = true;
        AM = false;
    }
    if(key == 97){ //A for AM
        FM = false;
        AM = true;
    }


}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){
    
    if(key == 51){
        square = false;
    }
    if(key == 52){
        saw = false;
    }
    if(key == 53){
        tri = false;
    }
    
}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y){
   
    
}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
   
    
}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){
    
    
}
//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){
    
}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){
    
}


//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){
    
}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){
    
}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){
    
}
