README.txt

To compile this project, ensure that this entire folder is placed inside the ‘app’ folder of an openFrameworks fork. You will need to have ofxMaxim and ofxGui installed in the addons folder within the project ‘guiExample.xcodeproj’. The project should automatically build and has many interactive mouse/key components.